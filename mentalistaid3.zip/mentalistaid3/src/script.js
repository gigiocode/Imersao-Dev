var numeroSecreto = parseInt(Math.random() * 11);

function Chutar() {
  var elementoResultado = document.getElementById("resultado");
  var chute = parseInt(document.getElementById("valor").value);
  console.log(chute);
  if (chute == numeroSecreto)
    document.getElementById("resultado").innerHTML = "Você acertou!";
  else if (chute > 10 || chute < 0)
    document.getElementById("resultado").innerHTML =
      "Você deve digitar um número de 0 a 10";
  else if (chute > numeroSecreto)
    document.getElementById("resultado").innerHTML =
      "Você errou.. O número é menor que " + chute;
  else
    document.getElementById("resultado").innerHTML =
      "Você errou.. O número é maior que " + chute;
}
