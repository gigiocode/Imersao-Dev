var nome = "gigiocode"
var notaPrimeiroBimestre = 6
var notaSegundoBimestre = 6
var notaTerceiroBimestre = 6
var notaQuartoBimestre = 6

var notaFinal = (notaPrimeiroBimestre + notaSegundoBimestre + notaTerceiroBimestre + notaQuartoBimestre) / 4

var notaFixada = notaFinal.toFixed (1)

console.log("Bem vindo, " + nome + "!")
console.log("Sua média é " + notaFixada + ".")

let a = 6

if (notaFixada >= a) 
  console.log("Você foi aprovado!")
  
else 
  console.log("Você foi reprovado!")








