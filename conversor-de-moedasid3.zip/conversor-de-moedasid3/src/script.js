function Converter() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmDolar = parseFloat(valor);

  var valorEmReal = valorEmDolar * 5;
  console.log(valorEmReal);

  var elementoValorConvertido = document.getElementById("valorConvertido");
  var valorConvertido = "O resultado em reais é R$ " + valorEmReal;

  elementoValorConvertido.innerHTML = valorConvertido;
}

function ConverterBtc() {
  var valorElemento = document.getElementById("valor");
  var valor = valorElemento.value;
  var valorEmDolar = parseFloat(valor);

  var valorEmBtc = valorEmDolar * 0.000021;
  console.log(valorEmBtc);

  var valorEmBtcFixado = valorEmBtc.toFixed(4);

  var elementoValorConvertidoBtc = document.getElementById(
    "valorConvertidoBtc"
  );
  var valorConvertidoBtc =
    "O resultado em Bitcoins é " + valorEmBtcFixado + " BTC";

  elementoValorConvertidoBtc.innerHTML = valorConvertidoBtc;
}
